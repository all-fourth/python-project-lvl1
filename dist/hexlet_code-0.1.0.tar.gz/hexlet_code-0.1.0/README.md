### Hexlet tests and linter status:
[![Actions Status](https://github.com/all-fourth/python-project-lvl1/workflows/hexlet-check/badge.svg)](https://github.com/all-fourth/python-project-lvl1/actions)
https://asciinema.org/a/FHjLFgM3SQEQokorJmnfT7a4b
https://asciinema.org/a/UvMwgIv6mQq4e7emaifHfv3Mp
https://asciinema.org/a/fMgEKl9DR29WupHZxcKHiSZBb
https://asciinema.org/a/PAyM3z4isMYIF6dnUCQW4o50m
https://asciinema.org/a/2J3gQtr8w4MzjAsazsA3zYeW1
